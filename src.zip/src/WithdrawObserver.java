public class WithdrawObserver implements Observer{

    String phone;


    public WithdrawObserver(String phone){
        this.phone = phone;
    }
    @Override
    public void notifyPhone(double amount,boolean success) {
        System.out.printf("Withdrew %.2f from your account %n", amount);
        if(success){
            System.out.println("Successful");
        }else {
            System.out.println("non successful");
        }
    }
}
