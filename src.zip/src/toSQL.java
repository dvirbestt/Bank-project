import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class toSQL {

    public static void clientWithdraw(String username,double amount) throws SQLException {
        Connection con = SQLConnection.getCon();
        Statement statement = con.createStatement();

        statement.execute("UPDATE clients_accounts SET balance = %.2f WHERE account_name = \"%s\""
                .formatted(amount,username));

    }

    public static void clientDeposit(String username,double amount) throws SQLException {
        Connection con = SQLConnection.getCon();
        Statement statement = con.createStatement();

        statement.execute("UPDATE clients_accounts SET balance = %.2f WHERE account_name = \"%s\""
                .formatted(amount,username));

    }
}
