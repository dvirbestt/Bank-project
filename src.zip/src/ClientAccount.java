import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ClientAccount implements Account {

    List<Observer> observers = new ArrayList<>();


    Scanner input = new Scanner(System.in);

    String userName;
    String firstName;
    String lastName;
    String address;
    String phone;
    double balance;

    public ClientAccount(String username) throws SQLException {
        getClientAccount(username);
        observers.add(new WithdrawObserver(phone));
        observers.add(new DepositObserver(phone));
    }

    @Override
    public void getMenu() throws SQLException {
        boolean running = true;
        while (running) {
            System.out.printf("hello %s%n", userName);
            System.out.println("to see all data pres: 1");
            System.out.println("to withdraw press: 2");
            System.out.println("to deposit press: 3");
            System.out.println("to exit press: 9");
            switch (input.nextInt()) {
                case 1 -> System.out.println(this);
                case 2 -> Withdraw();
                case 3 -> deposit();
                case 9 ->{
                    running = false;
                    logout();
                }
            }
        }
    }

    private void getClientAccount(String username) throws SQLException {
        Connection con = SQLConnection.getCon();
        Statement s = con.createStatement();

        ResultSet rs = s.executeQuery("select * from accounts,clients_accounts where user_name = \"%s\" and user_name = account_name;"
                .formatted(username));

        while (rs.next()){
            this.userName = username;
            this.firstName = rs.getString("first_name");
            this.lastName = rs.getString("last_name");
            this.address = rs.getString("address");
            this.phone = rs.getString("phone");
            this.balance = rs.getDouble("balance");

        }
    }

    public String toString(){
        return "Client: %s %s, address: %s, number: %s, Balance: %.2f".formatted(
                firstName,lastName,address,phone,balance
        );
    }

    public void Withdraw() throws SQLException {
        System.out.println("how much would you like to withdraw?: ");
        double amount = input.nextDouble();
        boolean s=false;

        if (amount > balance){
            System.out.println("could not withdraw do to lack of balance");

        }else {
            System.out.println("withdrawed");
            balance -= amount;
            toSQL.clientWithdraw(userName,balance);
            s = true;
        }

        for (Observer o: observers){
            if (o instanceof WithdrawObserver){
                o.notifyPhone(amount,s);
            }
        }
    }

    public void deposit() throws SQLException {
        System.out.println("how much would you like to deposit?: ");
        double amount = input.nextDouble();
        balance += amount;

        toSQL.clientDeposit(userName,balance);

        for (Observer o: observers){
            if (o instanceof DepositObserver){
                o.notifyPhone(amount,true);
            }
        }
    }

    public void logout() throws SQLException {
        new ClientAccount(null);
    }
}
