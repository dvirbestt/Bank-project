import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class GetInstance {

    static Scanner im = new Scanner(System.in);
    public GetInstance(){}


    public static Account getINSTANCE() throws SQLException {

        Connection con = SQLConnection.getCon();
        Statement statement = con.createStatement();



        System.out.println("Enter Username:");
        String username = im.next();
        System.out.println("Enter Password: ");
        String password = im.next();
        ResultSet rs = statement.executeQuery("select admin from accounts WHERE" +
                " user_name =\"%s\" AND password =\"%s\";".formatted(
                        username,password
                ));

        while (rs.next()){
            if (rs.getBoolean(1)){
                return new BankManagement(username);
            }else {
                return new ClientAccount(username);
            }
        }

        return null;
    }

}
