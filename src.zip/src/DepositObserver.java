public class DepositObserver implements Observer{

    String phone;

    public DepositObserver(String phone){
        this.phone = phone;
    }
    @Override
    public void notifyPhone(double amount, boolean success) {
        System.out.printf("Deposit completed added: %.2f%n", amount);
    }
}
