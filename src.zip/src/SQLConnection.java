import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLConnection {




    public static Connection getCon() throws SQLException {

            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank","root","root");
                return con;
            } catch (SQLException e) {

                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");

                Statement statement = con.createStatement();

                statement.execute("CREATE DATABASE bank");

                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank","root","root");

                statement = con.createStatement();

                statement.execute("CREATE TABLE accounts(" +
                        "  user_name varchar(20) PRIMARY KEY UNIQUE NOT NULL," +
                        "  password varchar(45) NOT NULL," +
                        "  admin tinyint(1));");


                statement.execute("CREATE TABLE clients_accounts (" +
                        "  first_name varchar(20) NOT NULL," +
                        "  last_name varchar(20) NOT NULL," +
                        "  address varchar(45) NOT NULL," +
                        " phone varchar(15) NOT NULL," +
                        "  id int NOT NULL UNIQUE," +
                        "  balance double," +
                        "  account_name varchar(20) NOT NULL," +
                        "CONSTRAINT FK_accounts FOREIGN KEY(account_name) REFERENCES accounts(user_name));");

                statement.execute("INSERT INTO accounts(user_name,password,admin)" +
                        "values(\"Admin1\",\"12345678\",1);");
                return con;
            }

        }



}
