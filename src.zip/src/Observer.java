public interface Observer {

     void notifyPhone(double amount,boolean success);
}
