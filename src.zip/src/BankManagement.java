
import java.sql.*;
import java.util.Scanner;

public class BankManagement implements Account{
    Scanner im = new Scanner(System.in);


    String username;
    public BankManagement(String username){
     this.username = username;
    }
    @Override
    public void getMenu() throws SQLException {
     boolean running =true;
     while (running) {
      System.out.printf("hello %s%n", username);
      System.out.println("to add a new client press: 1");
      System.out.println("to add a new admin press : 2");

      System.out.println("to exit press: 9");
      switch (im.nextInt()) {
       case 1 -> createClient();
       case 2 -> createAdmin();

       case 9 -> running = false;
       default -> System.out.println("wrong input");
      }
     }

    }

    public void createAdmin() throws SQLException {
     Connection con = SQLConnection.getCon();
     Statement statement = con.createStatement();

     System.out.println("Enter username -> password");

     statement.execute("INSERT INTO accounts(user_name,password,admin) values(" +
             "\"%s\",\"%s\",true);".formatted(
                     im.next(),im.next()
             ));
    }

    public void createClient() throws SQLException {
     Connection con = SQLConnection.getCon();
     Statement statement = con.createStatement();

     System.out.println("enter user name:");
     String newUsername = im.next();
     System.out.println("enter password: ");
     String pass = im.next();
     System.out.println("enter First Name: ");
     String fName = im.next();
     System.out.println("enter Last Name: ");
     String lName = im.next();
     System.out.println("enter address: ");
     String address = im.next();
     System.out.println("enter phone number");
     String phone = im.next();
     System.out.println("enter ID");
     int ID = im.nextInt();
     System.out.println("Enter balance: ");
     double balance = im.nextDouble();

     statement.execute("INSERT INTO accounts(user_name,password,admin) values(" +
             "\"%s\",\"%s\",false);".formatted(
                     newUsername,pass));

     statement.execute("INSERT INTO clients_accounts(first_name,last_name,address,phone,id,balance,account_name)" +
             " values(\"%s\",\"%s\",\"%s\",\"%s\",%d,%.2f,\"%s\"); ".formatted(
                     fName,lName,address,phone,ID,balance,newUsername
             ));

    }



}
