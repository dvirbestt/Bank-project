import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws SQLException {

        Scanner input = new Scanner(System.in);

        boolean running = true;
        while (running) {
            System.out.println("to login press: 1");
            System.out.println("to exit press: 2");
            switch (input.nextInt()){
                case 1-> {
                    Account ac = GetInstance.getINSTANCE();
                    ac.getMenu();
                }
                case 2-> running = false;
            }
        }
    }

}
