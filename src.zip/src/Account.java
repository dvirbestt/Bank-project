import java.sql.SQLException;

public interface Account {



    void getMenu() throws SQLException;
}
